// Programming session: 21
// Session: 15 minutes
// Date: Jan 31 2024

// ok what the f*ck should I be learning
// template literal for javascript huh 
// using ChatGPT andd other LLMs to learn coding, feels good man
// you know that feel bro when you're listening to KPOP and coding
// feels good man 

// why the f*ck is template literal better than regular strings?
// because it's dynamic and you can 

// I don't even bother using semicolon bro
// come at me 
const memberName = "rose" 

// why bother making message1 as const
// doesn't that take up more memory? 
// I'll ask Poe later 
// assign the template literal into the message1 cause why not 
const message1 = `${memberName} is the best in the group`

// using dynamic text template literal is able to insert itself 
// oh that's nice, let's see if it can do anything else 
console.log(message1) 

const rose_age = 20 

// rose age is 20
// but this message will add 15 into it
// that is a nice dynamic ok bro 
let message2 = `Rose age in 15 years will be: ${rose_age + 15}`
console.log(message2) 

console.log("42, is a fucking numeric literal expression mmmkay")
console.log('hello is a string literal, but is it an expression?')
console.log('we the javascript engine n shieeet')
console.log('javascript is the just-in-time interpeter n shieeet')

// variable name is an expression
// seems like there is so much expression in javascript 
// I'M ALL ABOUT THE FUCKING EXPRESSION
// 2 + 5, mathematical expression n shit.
// x > 5, comparsion. CAN ALSO USE OR, AND NOT TOO RIGHT
// || && ! come at me bro
// nevermind. so OR, NOT, AND is logical operators, heh
// function(x) as function expression okay gotchuuuuu 
// if (x >= 10) ... if statements as conditional ...

// okay I'm done with the 15 minutes of coding. bye. 
