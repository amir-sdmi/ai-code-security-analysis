const openAI = require("openAI");

// This code is obviously fake. The real purpose of this repository is to demo a GitSniff
// Maybe this code was written by ChatGPT ¯\_(ツ)_/¯ we've come full circle

console.log("Welcome to our High-Tech HackMIT submission! We've leveraged the powers of Deep Learning, NLP, and Cutting-Edge Transformer models to generate tailored solutions on how *your* business could be more eco-friendly!");
gpt_connection = openAI.connectToChatGPT();
answer = gpt_connection.query("Pretend you're a business owner. Write me a plan about how to save the planet");

console.log("Our AI model says that you should:");
console.log(answer);

console.log("\nThanks for using our tool 😄 Please vote for our project I need clout and bragging rights 🥺");
