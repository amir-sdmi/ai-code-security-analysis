const subtitleToArticle = async () => {

    // input from youtubeVideoSubtitleScrap
    // using chatgpt 3.5 or any with other AI tool
    //      rewrite article
    //      make summary
    //      make conclusion
    //      make titles
    //      make points 

    // return all infos with each name

}

module.exports = subtitleToArticle;