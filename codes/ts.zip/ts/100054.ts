import { dev } from '$app/environment';
export const BASE_URL = dev ? 'http://localhost:5173' : 'attendance.adamsc.xyz';
export const APP_NAME = 'Attendance Scanner';
export const CONTACT_EMAIL = 'abombsc@gmail.com';
export const DOMAIN = 'attendance.adamsc.xyz';
/* WARNING!!! TERMS AND CONDITIONS AND PRIVACY POLICY 
WERE CREATED BY CHATGPT AS AN EXAMPLE ONLY. 
CONSULT A LAWYER AND DEVELOP YOUR OWN TERMS AND PRIVACY POLICY!!! */
export const TERMS_PRIVACY_CONTACT_EMAIL = 'abombsc@gmail.com';
export const TERMS_PRIVACY_WEBSITE = 'attendance.adamsc.xyz/privacy';
export const TERMS_PRIVACY_COMPANY = 'Attendance Scanner';
export const TERMS_PRIVACY_EFFECTIVE_DATE = 'January 1, 2024';
export const TERMS_PRIVACY_APP_NAME = 'Attendance Scanner';
export const TERMS_PRIVACY_APP_PRICING_AND_SUBSCRIPTIONS =
	'[Details about the pricing, subscription model, refund policy]';
export const TERMS_PRIVACY_COUNTRY = 'United States';
